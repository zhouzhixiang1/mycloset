package com.example.styleout12;

public class Top {

    private int modelImage;

    public Top() {
    }

        public Top(int modelImage) {
            this.modelImage = modelImage;
        }

    public int getModelImage() {
        return modelImage;
    }

    public void setModelImage(int modelImage) {
        this.modelImage = modelImage;
    }
}
