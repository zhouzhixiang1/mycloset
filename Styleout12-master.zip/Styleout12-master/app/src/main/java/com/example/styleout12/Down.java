package com.example.styleout12;

public class Down {

    private int downImage;

    public Down() {
    }

    public Down(int downImage) {
        this.downImage = downImage;
    }

    public int getDownImage() {
        return downImage;
    }

    public void setDownImage(int downImage) {
        this.downImage = downImage;
    }
}
