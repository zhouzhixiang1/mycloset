package com.example.styleout12;

public class Up {

    private int upImage;

    public Up() {
    }

    public Up(int upImage) {
        this.upImage = upImage;
    }

    public int getUpImage() {
        return upImage;
    }

    public void setUpImage(int upImage) {
        this.upImage = upImage;
    }
}
